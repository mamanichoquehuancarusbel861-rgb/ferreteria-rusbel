<?php
return ['project-id-version'=>'WooCommerce 11.3.0','report-msgid-bugs-to'=>'https://wordpress.org/support/plugin/woocommerce','last-translator'=>'','language-team'=>'Español de Perú','mime-version'=>'1.0','content-type'=>'text/plain; charset=UTF-8','content-transfer-encoding'=>'8bit','pot-creation-date'=>'2026-11-11T12:39:00+00:00','po-revision-date'=>'2026-11-15 16:35+0000','x-generator'=>'Loco https://localise.biz/','x-domain'=>'woocommerce
','language'=>'es_PE','plural-forms'=>'nplurals=2; plural=n != 1;','x-loco-version'=>'2.8.9; wp-7.1.4; php-8.1.34','messages'=>[]];
