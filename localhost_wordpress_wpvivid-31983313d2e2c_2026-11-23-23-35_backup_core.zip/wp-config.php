<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the website, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * Database settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://developer.wordpress.org/advanced-administration/wordpress/wp-config/
 *
 * @package WordPress
 */

// ** Database settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'mi_wordpress' );

/** Database username */
define( 'DB_USER', 'root' );

/** Database password */
define( 'DB_PASSWORD', '' );

/** Database hostname */
define( 'DB_HOST', 'localhost' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         'g3 %l0efvp{$zhuhoQ.}H.f:x8QhV5XDQ6ZG:1e3<7x;V$*,f{P+b8j4ma%U^ ~G' );
define( 'SECURE_AUTH_KEY',  '~LSo&#+]E*xk`*jgeP7n{A~tzuX,`MllBOe9(;ENmu}W%<p- X+ORwG49CmuB-UV' );
define( 'LOGGED_IN_KEY',    'yg9xb?!:0eR4%Xe+3se}(A4Qlm|e)!MZmnU=As$}y0A[J@Jg{:**m%Mthnnd- Qb' );
define( 'NONCE_KEY',        'GBem)MZeh82N!M+dKO?3q-m~OpBe(g?XH;e0h.5TPzJ%|W9@dfO8VUbPBst @)r<' );
define( 'AUTH_SALT',        'tD@;*@_$):R$?r6cK#VNI8fHDm/,wqJvo(v{__{*6tE*9{qz2[d ;xrJ->B22knG' );
define( 'SECURE_AUTH_SALT', 'L~>3w_@|&<{q3:?6sk(Nx|8|6Pt6yOepfSRi%Tm&R]CP9pE0GWjy}$7Js*N*)cOT' );
define( 'LOGGED_IN_SALT',   'qNlbf($h6v=|i<+X9Q-CcQj8tX Zwu6]nEgue$?:W#Il&o+nSPCa#a`ynXLnx?v/' );
define( 'NONCE_SALT',       '.W/cF>86]C(s<=L!<V}sip<W>L^&C.%WJ-n%S:!mFUtq{_e.D|p0K:/+xPHrLn_B' );

/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 *
 * At the installation time, database tables are created with the specified prefix.
 * Changing this value after WordPress is installed will make your site think
 * it has not been installed.
 *
 * @link https://developer.wordpress.org/advanced-administration/wordpress/wp-config/#table-prefix
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://developer.wordpress.org/advanced-administration/debug/debug-wordpress/
 */
define( 'WP_DEBUG', false );

/* Add any custom values between this line and the "stop editing" line. */



/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
