=== Google for WooCommerce ===
Contributors: automattic, google, woocommerce
Tags: woocommerce, google, product feed, ads, listings
Requires at least: 6.9
Tested up to: 7.1
Requires PHP: 7.4
Requires PHP Architecture: 64 Bits
Stable tag: 3.10.0
License: GPLv3
License URI: https://www.gnu.org/licenses/gpl-3.0.html

Native integration with Google that allows merchants to easily display their products across Google’s network.

== Description ==

Effortlessly sync your WooCommerce product feed across Google and be seen by millions of engaged shoppers with the Google for WooCommerce extension. Download and setup takes just five minutes.

**Grow your business with $500 in Google Ads credit**

To help you get started running campaigns, you can get $500 in ad credit when you spend your first $500 on Google Ads within 60 days.

*Terms and conditions apply.*

**Sync your WooCommerce product feed to Google Merchant Center**

Seamlessly integrate your WooCommerce store with Google and set yourself up for success.

- **Sync your WooCommerce product feed to Google Merchant Center** in just a few clicks. With our API-integrated Product Sync feature, all the data and functionalities from your WooCommerce store will be linked to Google with seamless server-to-server connection.

- **Have your product listings automatically updated in real time** so your prices, promotions, inventories, and other product details stay accurate and synchronized across all your listings.

- **Access all the tools and features you need** to manage your WooCommerce store and grow your business — centralized in one place.

**Find the right audiences and sell to high-intent customers with Google Ads**

Now your WooCommerce store is discoverable on Google – and you’re ready to **launch a Google Ads campaign!**

- **Put Google AI to work for you** by launching a Google Ads Performance Max campaign. Combined with your unique business insight, Performance Max can help you reach high-value customers using optimized placements, bidding, and more – all aligned with your budget and specific goals.
- **Showcase your products across Google Shopping, Search, YouTube, Gmail, Maps, Display, and Discover** – from a single campaign. Manage all your Google Ads campaigns from your WooCommerce dashboard and on the WooCommerce Mobile App.
- **Save time and effort** by using Google AI to help scale your asset creation. Performance Max will not only create additional copy and images based on the creative you upload, but also mix and match them for the best performing ad combinations.

**Get custom insights and improve your conversions using Google tag**

Once you’re running Google Ads campaigns, the Google tag feature in the extension enables conversion tracking to give you insights — so you can test and learn what works, and fine-tune your strategy.

- **Easily adjust your product listings in real time** to reflect your learnings and business expertise. While the extension maps product attributes by default, it’s simple to modify if you’d like more control.
- **Leverage automatic Google tagging and conversion tracking to measure what’s working and what’s not.** With insight into your customers’ purchase journey, you’ll be able to pinpoint how effectively your ads translate into valuable customer activity.
- **Take your conversion tracking further with enhanced conversions** — a feature designed to improve your measurement accuracy by collecting privacy-conscious data without the need for third-party cookies. So you have the right data to help make your campaign more effective.

== Installation ==

= Minimum Requirements =

* WordPress 6.8 or greater
* WooCommerce 11.0 or greater
* PHP version 7.4 or greater
* PHP Architecture 64 bits
* MySQL version 5.6 or greater

Visit the [WooCommerce server requirements documentation](https://woocommerce.com/document/server-requirements/) for a detailed list of server requirements.

= Automatic installation =

Automatic installation is the easiest option as WordPress handles the file transfers itself and you don’t need to leave your web browser. To do an automatic install of this plugin, log in to your WordPress dashboard, navigate to the Plugins menu and click Add New.

In the search field type “Google for WooCommerce” and click Search Plugins. Once you’ve found this plugin you can view details about it such as the point release, rating and description. Most importantly of course, you can install it by simply clicking “Install Now”.

= Manual installation =

The manual installation method involves downloading the plugin and uploading it to your webserver via your favourite FTP application. The WordPress codex contains [instructions on how to do this here](https://codex.wordpress.org/Managing_Plugins#Manual_Plugin_Installation).

= Where can I report bugs or contribute to the project? =

Bugs should be reported in the [Google for WooCommerce GitHub repository](https://github.com/woocommerce/google-listings-and-ads/).

= This is awesome! Can I contribute? =

Yes you can! Join in on our [GitHub repository](https://github.com/woocommerce/google-listings-and-ads/) :)

Release and roadmap notes available on the [WooCommerce Developers Blog](https://woocommerce.wordpress.com/)

== FAQ ==

= What is Google Merchant Center? =
[Google Merchant Center](https://woocommerce.com/document/google-for-woocommerce/#connect-your-store-with-google-merchant-center) is like a digital storefront for your products on Google. It’s where you upload and manage information about your products, like titles, descriptions, images, prices, and availability. This data is used to create product listings that can appear across Google.

= Why should I connect to Google Merchant Center? =
By syncing your product information to [Google Merchant Center](https://woocommerce.com/document/google-for-woocommerce/#connect-your-store-with-google-merchant-center), your products can appear in relevant Google searches, Shopping tab, image searches, and even on other platforms like YouTube. When running [Performance Max campaigns](https://woocommerce.com/document/google-for-woocommerce/get-started/google-performance-max-campaigns/), Google Merchant Center ensures that shoppers see the most up-to-date and accurate information about your product feed, reducing confusion and improving the chances of a purchase.

= Will my deals and promotions display on Google? =
To show your coupons and promotions on Google Shopping listings, make sure you’re using the latest version of Google for WooCommerce. When you create or update a coupon in your WordPress dashboard under Marketing > Coupons, you’ll see a Channel Visibility settings box on the right: select “Show coupon on Google” to enable it. [Learn more](https://support.google.com/merchants/answer/11338950#zippy=%2Cmanage-promotions-using-woocommerce) about managing promotions for Google for WooCommerce. This feature is currently available in Australia, Canada, Germany, France, India, the United Kingdom, and the United States.

= What is Product Sync? =
Product Sync is a feature fully integrated into WooCommerce’s management platform that automatically lets you sync your product feed to Google Merchant Center. It will sync all your WooCommerce product data, and you can also add or edit products individually or in bulk. To ensure products are approved by Google, check that your product feed includes the following information:
<p> <br> </p>
* General product information
* Unique product identifiers
* Data requirements for specific categories (auto-assigned by Google):
	* Apparel & Accessories
	* Media
	* Books

= Where do I manage my product feed and my Google Ads campaigns? =
You can manage and edit all of your products and your Google Ads campaigns right from your WooCommerce dashboard and on the WooCommerce Mobile App.

= Where will my products appear? =
Once you start running a [Performance Max campaign](https://woocommerce.com/document/google-for-woocommerce/get-started/google-performance-max-campaigns/), your approved products will reach more shoppers to help grow your business by being shown on Google Search, Google Maps, the Shopping tab, Gmail, Youtube, the Google Display Network, and Discover feed.

= What are Performance Max campaigns? =
[Performance Max campaigns](https://woocommerce.com/document/google-for-woocommerce/get-started/google-performance-max-campaigns/) help you combine your expertise with Google AI to reach your most valuable customers and drive sales. Just set your goals and budget and Google AI will get your ads seen by the right customers at the right time across Google Search, Google Maps, the Shopping tab, Gmail, Youtube, the Google Display Network, and Discover feed.

= How much do Performance Max campaigns cost? =
[Performance Max campaigns](https://woocommerce.com/document/google-for-woocommerce/get-started/google-performance-max-campaigns/) are pay-per-click, meaning you only pay when someone clicks on your ads. To get the best results and ensure your products reach the right customers, we recommend starting with the suggested Google for WooCommerce minimum daily budget for your [Performance Max campaign](https://woocommerce.com/document/google-for-woocommerce/get-started/google-performance-max-campaigns/). This helps jumpstart your campaign and drive early conversions. You can always adjust your budget later as you see what works best for your business.

= Can I sync my products and run Performance Max campaigns on Google for WooCommerce at the  same time? =
Yes, you can run both at the same time, and we recommend you do! Once you sync your store it’s automatically listed on Google, so you can choose to run a paid [Performance Max campaign](https://woocommerce.com/document/google-for-woocommerce/get-started/google-performance-max-campaigns/) as soon as you’d like. In the US, advertisers who sync their products to Google and run Google Ads [Performance Max campaigns](https://woocommerce.com/document/google-for-woocommerce/get-started/google-performance-max-campaigns/) have seen an average of over 50% increase in clicks and over 100% increase in impressions in both their product listings and their ads on the Shopping tab.

= How does Google for WooCommerce help me drive sales? =
With Google for WooCommerce, you can serve the best-performing ads more often, by using Google AI to pull headlines, images, product details, and more from your product feed and find more relevant customers. Your campaigns will learn and optimize in real time – to help deliver better performance and boost your ROI.

= What are Enhanced conversions? =
Enhanced conversions is a feature that can improve the accuracy of your conversion measurement and unlock more powerful bidding. It supplements your existing conversion tags by sending hashed first-party conversion data from your website to Google in a privacy-safe way.

= Which countries are available for Google for WooCommerce? =
For [Performance Max campaigns](https://woocommerce.com/document/google-for-woocommerce/get-started/google-performance-max-campaigns/), learn more about supported countries and currencies [here](https://support.google.com/merchants/answer/160637#countrytable).

= What is Multi-Country Advertising? =
Multi-Country Advertising enables you to create a single Google Ads campaign that targets multiple countries at once. Google for WooCommerce automatically populates eligible countries from your Google Merchant Center account into the plug-in ads campaign creation flow.

= Can I enable Multi-Country Advertising on my existing campaigns? =
If you created a campaign before this feature launched, you’ll need to create a new campaign to target new countries with Multi-Country Advertising. [Learn more](https://woocommerce.com/document/google-listings-and-ads/).

= How is my ads budget split between the different countries? =
Identify the best performing targeted countries with the help of Google AI, to make your ads reach the right shoppers at the right time.

= Which countries can I target? =
You can only select the countries that you’re targeting on Google Merchant Center. Your target countries must be eligible for both Google Merchant Center and Google Ads.

To allow your products to appear in all relevant locations, make sure you’ve correctly [configured your shipping](https://support.google.com/merchants/answer/6069284) for countries where your products can be delivered. Keep in mind that shipping services can cover multiple countries. [Learn more about multi-country shipping](https://support.google.com/merchants/answer/6069284#multicountryshipping).

== Changelog ==

= 3.10.0 - 2026-10-20 =
* Add - Let merchants collect Google Customer Reviews after purchase and display their aggregate Google rating on the storefront.
* Update - Remove the US tax rate setting, as Google is retiring the US Sales Tax service.
* Tweak - Improved account connection experience for service-based merchants.
* Tweak - Remove unused phone verification routes and Content API product calls.
* Tweak - Remove the remaining API Pull code.
* Tweak - Harden the Connection Test debug page and add Merchant API Data Sources tools.
* Fix - Prevent product and promotion sync from stalling when the plugin resolves a Merchant Center data source that only accepts file uploads or local products, and point the resulting error at data source guidance instead of a product attribute that doesn't exist.
* Fix - Validate the product and coupon content language against Merchant Center supported languages, falling back to English, so unsupported locale or WPML codes no longer block syncing.
* Fix - Translate Content API keys and drop unknown keys returned by the `woocommerce_gla_product_attribute_values` filter, so products still sync to Merchant Center.
* Fix - Product status refresh failing with a TypeError when a variable product holds both its own and its variations' pre-sync errors.

= 3.9.6 - 2026-10-12 =
* Add - Show a dismissible Google Ads promo on the WooCommerce Analytics Overview page when product revenue or products sold decline.
* Add - Add multilingual and multicurrency market counts in the tracker snapshot.
* Add - Notify merchants when synced products have main images smaller than 500 x 500 pixels.
* Tweak - Replace channel visibility select with a toggle control.
* Tweak - Bump WooCommerce "tested up to" version 11.2.
* Tweak - Bump WooCommerce minimum supported version to 11.0.
* Fix - Skip ads settings fetch when no Google Ads account connected.
* Fix - Show the notification count bubble on the correct menu item after returning from Settings.
* Fix - Settings tabs are no longer hidden behind the WooCommerce header after editing your store address or a paid ads campaign.
* Fix - Record campaign-management FAQ interactions with the documented event name.
* Fix - Support Content API-style getters (e.g. `getLink()`) on the adapter passed to `woocommerce_gla_product_attribute_values`, so extensions that read them no longer break product sync.

= 3.9.5 - 2026-09-29 =
* Fix - Fixed security issues.

[See changelog for all versions](https://raw.githubusercontent.com/woocommerce/google-listings-and-ads/trunk/changelog.txt).
