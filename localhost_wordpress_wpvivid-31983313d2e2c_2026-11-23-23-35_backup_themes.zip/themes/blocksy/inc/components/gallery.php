<?php

function blocksy_get_flexy_arrows() {
	/**
	 * Filters the icons rendered inside the flexy slider arrows.
	 *
	 * Applies to both the main slider arrows and the pills arrows.
	 *
	 * @since 2.0.98
	 *
	 * @param array $arrow_icons Arrow icons markup, keyed `prev` and `next`.
	 */
	return apply_filters(
		'blocksy:flexy:arrows',
		array(
			'prev' => '<svg width="16" height="10" fill="currentColor" viewBox="0 0 16 10"><path d="M15.3 4.3h-13l2.8-3c.3-.3.3-.7 0-1-.3-.3-.6-.3-.9 0l-4 4.2-.2.2v.6c0 .1.1.2.2.2l4 4.2c.3.4.6.4.9 0 .3-.3.3-.7 0-1l-2.8-3h13c.2 0 .4-.1.5-.2s.2-.3.2-.5-.1-.4-.2-.5c-.1-.1-.3-.2-.5-.2z"></path></svg>',
			'next' => '<svg width="16" height="10" fill="currentColor" viewBox="0 0 16 10"><path d="M.2 4.5c-.1.1-.2.3-.2.5s.1.4.2.5c.1.1.3.2.5.2h13l-2.8 3c-.3.3-.3.7 0 1 .3.3.6.3.9 0l4-4.2.2-.2V5v-.3c0-.1-.1-.2-.2-.2l-4-4.2c-.3-.4-.6-.4-.9 0-.3.3-.3.7 0 1l2.8 3H.7c-.2 0-.4.1-.5.2z"></path></svg>',
		)
	);
}

if ( ! function_exists( 'blocksy_flexy' ) ) {
	function blocksy_flexy( $args = array() ) {
		$args = wp_parse_args(
			$args,
			array(
				'prefix'                => '',

				'items'                 => '',
				'images'                => null,
				'images_ratio'          => '3/4',

				'pills_images'          => null,
				'pills_images_ratio'    => '1/1',

				'pills_count'           => 0,

				'items_container_class' => '',
				'class'                 => '',

				'size'                  => 'medium',
				'lazyload'              => true,
				'href'                  => null,

				'has_pills'             => true,

				'enable'                => true,
				'has_arrows'            => true,

				'arrows_class'          => '',

				'container_attr'        => array(),
				'slide_inner_content'   => '',

				'autoplay'              => false,

				'slide_image_args'      => null,

				'active_index'          => 1,

				'visible_items'         => null,
			)
		);

		wp_enqueue_style( 'ct-flexy-styles' );

		$has_scale_rotate = false;

		if ( $args['images'] ) {
			$args['pills_count'] = count( $args['images'] );
			$args['items']       = '';

			$visible_start = 1;
			$visible_end   = $args['pills_count'];

			if ( $args['visible_items'] ) {
				$visible_start = max(
					1,
					min(
						intval( $args['active_index'] ),
						$args['pills_count'] - intval( $args['visible_items'] ) + 1
					)
				);

				$visible_end = $visible_start + intval( $args['visible_items'] ) - 1;
			}

			$position = 0;

			foreach ( $args['images'] as $index => $single_image ) {
				++$position;

				$attachment_id = $single_image;

				if (
				is_array( $single_image )
				&&
				isset( $single_image['attachment_id'] )
				) {
					$attachment_id = $single_image['attachment_id'];
				}

				if ( $has_scale_rotate ) {
					$args['items'] .= '<div>';
				}

				$single_item_href = $args['href'];
				$width            = null;
				$height           = null;

				if ( ! $single_item_href ) {
					$single_item_href = wp_get_attachment_image_src(
						$attachment_id,
						'full'
					);

					if ( $single_item_href ) {
						$width  = $single_item_href[1];
						$height = $single_item_href[2];

						$single_item_href = $single_item_href[0];
					}
				}

				$class = 'flexy-item';

				$slide_wrapper_attr = array();

				$slide_args = array(
					'display_video' => true,
					'no_image_type' => 'woo',
					'attachment_id' => $attachment_id,
					'ratio'         => $args['images_ratio'],
					'tag_name'      => 'figure',
					'size'          => $args['size'],
					'html_atts'     => array_merge(
						array(
							'data-src' => $single_item_href,
						// 'href' => $single_item_href
						),
						$width ? array(
							'data-width'  => $width,
							'data-height' => $height,
						) : array()
					),
					'inner_content' => $args['slide_inner_content'],
					'lazyload'      => $args['lazyload'],
				);

				if ( $args['slide_image_args'] ) {
					$slide_args = call_user_func(
						$args['slide_image_args'],
						$index,
						$slide_args
					);
				}

				if ( ! empty( $class ) ) {
					$slide_wrapper_attr['class'] = $class;
				}

				$is_lazy_zone = $position < $visible_start || $position > $visible_end;

				if ( $is_lazy_zone ) {
					blocksy_lazy_zone_start();
				}

				/**
				 * Filters the media arguments of a single flexy slider slide.
				 *
				 * @since 2.0.1
				 *
				 * @param array $slide_args Arguments passed to blocksy_media() for the slide.
				 */
				$slide_media_args = apply_filters(
					'blocksy:woocommerce:image_additional_attributes',
					$slide_args
				);

				$slide_media = blocksy_media( $slide_media_args );

				if ( $is_lazy_zone ) {
					blocksy_lazy_zone_end();
				}

				$args['items'] .= blocksy_html_tag(
					'div',
					$slide_wrapper_attr,
					$slide_media
				);

				if ( $has_scale_rotate ) {
					$args['items'] .= '</div>';
				}
			}
		}

		if ( $args['enable'] ) {
			$initial_value = 'no';

			if ( $has_scale_rotate ) {
				$initial_value = 'no:scalerotate';
			}

			$args['container_attr']['data-flexy'] = $initial_value;

			if ( $args['active_index'] > 1 ) {
				$args['container_attr']['style'] = '--current-item: ' . ( intval(
					$args['active_index']
				) - 1 );
			}
		} else {
			$args['container_attr'] = array();
		}

		// Slider view
		// boxed | full
		$slider_view = 'boxed';

		if ( $args['autoplay'] ) {
			$args['container_attr']['data-autoplay'] = $args['autoplay'];
		}

		$container_attr = blocksy_attr_to_html( $args['container_attr'] );

		$class = trim( 'flexy-container ' . $args['class'] );

		$args['items_container_class'] = trim(
			'flexy-items ' . $args['items_container_class']
		);

		?>

	<div
		class="<?php echo $class; ?>"
		<?php echo $container_attr; ?>>
		<div class="flexy">
			<div class="flexy-view" data-flexy-view="<?php echo $slider_view; ?>">
				<div
					class="<?php echo $args['items_container_class']; ?>">
					<?php echo $args['items']; ?>
				</div>
			</div>

			<?php
			if ( $args['has_arrows'] ) {
				$arrow_icons = blocksy_get_flexy_arrows();
				?>
				<span class="<?php echo trim( 'flexy-arrow-prev' . ' ' . $args['arrows_class'] ); ?>">
					<?php echo $arrow_icons['prev']; ?>
				</span>

				<span class="<?php echo trim( 'flexy-arrow-next' . ' ' . $args['arrows_class'] ); ?>">
					<?php echo $arrow_icons['next']; ?>
				</span>
			<?php } ?>
		</div>

			<?php
			if ( $args['has_pills'] ) {
				blocksy_flexy_pills( $args );
			}
			?>
	</div>
		<?php
	}
}

if ( ! function_exists( 'blocksy_flexy_pills' ) ) {
	function blocksy_flexy_pills( $args = array() ) {
		$args = wp_parse_args(
			$args,
			array(
				'pills_count'          => 0,
				'pills_images'         => null,
				'pills_images_ratio'   => '1/1',
				'pills_container_attr' => array(),
				'pills_have_arrows'    => false,
				'active_index'         => 1,
				'pills_arrows_class'   => '',
				'pills_class'          => '',
			)
		);

		if ( 0 === $args['pills_count'] ) {
			return;
		}

		$type = $args['pills_images'] ? 'thumbs' : 'circle';

		$container_attr = blocksy_attr_to_html( $args['pills_container_attr'] );

		if ( ! empty( $container_attr ) ) {
			$container_attr = ' ' . $container_attr;
		}

		$class = 'flexy-pills';

		if ( ! empty( $args['pills_class'] ) ) {
			$class .= ' ' . $args['pills_class'];
		}

		echo '<div class="' . $class . '" data-type="' . $type . '">';
		echo '<ol' . $container_attr . '>';

		foreach ( range( 1, ceil( $args['pills_count'] ) ) as $index ) {
			if ( $args['pills_images'] ) {
				$class = '';

				if ( intval( $index ) === $args['active_index'] ) {
					$class = ' class="active"';
				}

				blocksy_lazy_zone_start();

				$image_output = '<li' . $class . '>' . blocksy_media(
					array(
						'attachment_id' => $args['pills_images'][ $index - 1 ],
						'ratio'         => $args['pills_images_ratio'],
						'tag_name'      => 'span',
						'size'          => 'woocommerce_gallery_thumbnail',
						'html_atts'     => array(
							'aria-label' => blocksy_safe_sprintf(
								// translators: %s is the slide number.
								__( 'Slide %s', 'blocksy' ),
								$index
							),
						),
						// TODO: need to discuss
						'display_video' => 'pill',
						'lazyload'      => $args['lazyload'],
					)
				) . '</li>';

				blocksy_lazy_zone_end();

				echo $image_output;
			} else {
				echo blocksy_html_tag(
					'li',
					array_merge(
						array(
							'aria-label' => blocksy_safe_sprintf(
								// translators: %s is the slide number.
								__( 'Slide %s', 'blocksy' ),
								$index
							),
						),
						intval( $index ) === $args['active_index'] ? array(
							'class' => 'active',
						) : array()
					),
					''
				);
			}
		}

		echo '</ol>';

		if ( $args['pills_have_arrows'] ) {
			$arrow_icons = blocksy_get_flexy_arrows();

			echo '<span class="' . trim( 'flexy-arrow-prev' . ' ' . $args['pills_arrows_class'] ) . '">' . $arrow_icons['prev'] . '</span>
							<span class="' . trim( 'flexy-arrow-next' . ' ' . $args['pills_arrows_class'] ) . '">' . $arrow_icons['next'] . '</span>';
		}

		echo '</div>';
	}
}
