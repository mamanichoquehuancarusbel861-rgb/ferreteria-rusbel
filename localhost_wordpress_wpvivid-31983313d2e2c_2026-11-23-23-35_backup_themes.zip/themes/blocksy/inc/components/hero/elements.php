<?php
// phpcs:disable WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound, VariableAnalysis.CodeAnalysis.VariableAnalysis.UndefinedVariable -- view scope, variables come from blocksy_render_view()

$prefix = blocksy_manager()->screen->get_prefix();

if ( function_exists( 'tutor_utils' ) && 'courses_single' === $prefix ) {
	if ( tutor_utils()->is_enrolled() ) {
		tutor_course_enrolled_lead_info();
	} else {
		tutor_course_lead_info();
	}

	return;
}

$is_page = blocksy_is_page();

$default_hero_elements = array();

$default_hero_elements[] = array(
	'id'      => 'custom_title',
	'enabled' => 'product' !== $prefix,
);

if ( ! function_exists( 'tutor_utils' ) && 'courses_archive' !== $prefix ) {
	$default_hero_elements[] = array(
		'id'      => 'custom_description',
		'enabled' => 'product' !== $prefix,
	);
}

if (
	(
		is_singular() || is_author()
	) && ! (
		function_exists( 'is_bbpress' ) && (
			get_post_type() === 'forum'
			||
			get_post_type() === 'topic'
			||
			get_post_type() === 'reply'
			||
			get_query_var( 'post_type' ) === 'forum'
			||
			bbp_is_topic_tag()
			||
			bbp_is_topic_tag_edit()
			||
			is_bbpress()
		)
	) && ! ( get_post_type() === 'elementor_library' )
) {
	$default_hero_elements[] = array(
		'id'      => 'custom_meta',
		'enabled' => ! $is_page && 'product' !== $prefix,
	);
}

if ( is_author() ) {
	$default_hero_elements[] = array(
		'id'      => 'author_social_channels',
		'enabled' => true,
	);
}

$default_hero_elements[] = array(
	'id'      => 'breadcrumbs',
	'enabled' => 'product' === $prefix,
);

$hero_elements = blocksy_akg_or_customizer(
	'hero_elements',
	blocksy_get_page_title_source(),
	$default_hero_elements
);

$meta_indexes = array(
	'first'  => null,
	'second' => null,
);

foreach ( $hero_elements as $index => $single_hero_element ) {
	if ( ! isset( $single_hero_element['enabled'] ) ) {
		continue;
	}

	if ( 'custom_meta' === $single_hero_element['id'] ) {
		if ( null === $meta_indexes['first'] ) {
			$meta_indexes['first'] = $index;
		} else {
			$meta_indexes['second'] = $index;
		}
	}
}

foreach ( $hero_elements as $index => $single_hero_element ) {
	if ( ! isset( $single_hero_element['enabled'] ) ) {
		continue;
	}

	if ( ! $single_hero_element['enabled'] ) {
		continue;
	}

	/**
	 * Fires before a single hero element is rendered.
	 *
	 * The dynamic portion of the hook name, `$single_hero_element['id']`, refers
	 * to the hero element id (e.g. `custom_title`, `breadcrumbs`, `post_meta`).
	 *
	 * @since 1.7.10
	 */
	do_action( 'blocksy:hero:' . $single_hero_element['id'] . ':before' );

	/**
	 * Fires while a single hero element is rendered.
	 *
	 * @since 1.8.4
	 *
	 * @param array $single_hero_element The hero element configuration.
	 */
	do_action( 'blocksy:hero:element:render', $single_hero_element );

	if ( 'breadcrumbs' === $single_hero_element['id'] ) {
		$breadcrumbs_builder = new \Blocksy\BreadcrumbsBuilder();

		echo $breadcrumbs_builder->render(
			array(
				'class' => blocksy_visibility_classes(
					blocksy_akg(
						'breadcrumbs_visibility',
						$single_hero_element,
						array(
							'desktop' => true,
							'tablet'  => true,
							'mobile'  => true,
						)
					)
				),
			)
		);
	}

	if ( 'custom_title' === $single_hero_element['id'] ) {
		$has_author_avatar = false;

		if (
			blocksy_akg( 'has_author_avatar', $single_hero_element, 'yes' ) === 'yes'
		) {
			if ( is_author() ) {
				$has_author_avatar = true;
			}
		}

		$title = '';

		$has_category_label_default = 'yes';

		if ( 'courses_archive' === $prefix && function_exists( 'tutor' ) ) {
			$has_category_label_default = 'no';
		}

		$has_category_label = blocksy_akg(
			'has_category_label',
			$single_hero_element,
			$has_category_label_default
		);

		if ( function_exists( 'is_woocommerce' ) && is_woocommerce() ) {
			$has_category_label = 'no';
		}

		if (
			(
				is_singular() || blocksy_is_page() || 'bbpress_single' === $prefix
			) && ! is_search()
		) {
			if ( ! $post_id ) {
				$post_id = get_the_ID();
			}

			if ( ! empty( get_the_title( $post_id ) ) ) {
				$title = get_the_title( $post_id );
			}
		} else {
			if ( ! is_search() ) {
				if ( ! empty( get_the_archive_title() ) ) {
					$archive_title_renderer = new \Blocksy\ArchiveTitleRenderer(
						array(
							'has_label' => 'yes' === $has_category_label,
						)
					);

					$title = $archive_title_renderer->get_the_archive_title();
				}

				if ( is_author() ) {
					$title = blocksy_get_the_author_meta(
						'display_name',
						blocksy_get_author_id()
					);
				}
			} else {
				$title = blocksy_safe_sprintf(
					// translators: 1: the search query
					__(
						'Search Results for %1$s',
						'blocksy'
					),
					get_search_query()
				);
			}
		}

		if ( is_home() && is_front_page() ) {
			$title = blocksy_sanitize_html_for_display(
				array(
					'html' => blocksy_translate_dynamic(
						blocksy_akg(
							'title',
							$single_hero_element,
							(
							function_exists( 'is_shop' ) && is_shop()
							) ? __( 'Products', 'blocksy' ) : __( 'Home', 'blocksy' )
						),
						$prefix . '_hero_custom_title'
					),
				)
			);
		}

		// woocommerce_page_title gives plain text title, without any html tags.
		// Thus, we need to call it before we wrap the title in a tag.
		if ( function_exists( 'is_woocommerce' ) && is_woocommerce() ) {
			$title = apply_filters( 'woocommerce_page_title', $title ); // phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedHooknameFound -- WooCommerce core filter
		}

		if ( ! empty( $title ) ) {
			$title_attrs = array(
				'class' => 'page-title',
			);

			$custom_attribute = blocksy_akg(
				'custom_attribute',
				$single_hero_element,
				''
			);

			if ( ! empty( $custom_attribute ) ) {
				foreach ( blocksy_parse_html_attributes( $custom_attribute ) as $attr_name => $attr_value ) {
					if ( ! blocksy_is_allowed_custom_attribute_name( $attr_name ) ) {
						continue;
					}

					$title_attrs[ $attr_name ] = str_replace(
						'{title}',
						strip_tags( $title ),
						$attr_value
					);
				}
			}

			$heading_tag = blocksy_validate_html_tag(
				array(
					'tag'     => blocksy_akg( 'heading_tag', $single_hero_element ),
					'allowed' => 'headings',
					'default' => 'h1',
				)
			);

			$title = blocksy_html_tag(
				$heading_tag,
				array_merge(
					$title_attrs,
					blocksy_schema_org_definitions(
						'headline',
						array(
							'array' => true,
						)
					)
				),
				$title
			);
		}

		if ( is_author() ) {
			echo '<div class="ct-author-name">';
		}

		if ( $has_author_avatar ) {
			$avatar_size = intval(
				blocksy_akg(
					'author_avatar_size',
					$single_hero_element,
					'60'
				)
			) * 2;

			$title = blocksy_simple_image(
				/**
				 * Filters the author avatar URL used in the author hero title.
				 *
				 * @since 1.8.6.8
				 *
				 * @param string $avatar_url The resolved author avatar URL.
				 */
				apply_filters(
					'blocksy:hero:title:author:author-avatar-url',
					blocksy_get_avatar_url( array( 'size' => $avatar_size ) )
				),
				array(
					'tag_name'     => 'span',
					'aspect_ratio' => false,
					'suffix'       => 'static',
					'img_atts'     => array(
						'width'  => $avatar_size / 2,
						'height' => $avatar_size / 2,
						'style'  => 'height:' . (
							intval( $avatar_size ) / 2
						) . 'px',
						'alt'    => blocksy_get_avatar_alt_for( blocksy_get_the_author_meta( 'ID' ) ),
					),
				)
			) . $title;
		}

		/**
		 * Fires before the hero title is printed.
		 *
		 * @since 1.7.17
		 */
		do_action( 'blocksy:hero:title:before' );
		echo $title;
		/**
		 * Fires after the hero title is printed.
		 *
		 * @since 1.7.17
		 */
		do_action( 'blocksy:hero:title:after' );

		if ( is_author() ) {
			echo '</div>';
		}
	}

	if ( 'custom_description' === $single_hero_element['id'] ) {
		$description       = '';
		$description_class = 'page-description';

		$description_class .= ' ' . blocksy_visibility_classes(
			blocksy_akg(
				'description_visibility',
				$single_hero_element,
				array(
					'desktop' => true,
					'tablet'  => true,
					'mobile'  => false,
				)
			)
		);

		if (
			(
				is_singular() || $is_page || 'bbpress_single' === $prefix
			) && ! is_search()
		) {
			if ( ! $post_id ) {
				$post_id = $is_page ? $is_page : get_the_ID();
			}

			if ( function_exists( 'is_woocommerce' ) && is_shop() ) {
				ob_start();
				woocommerce_taxonomy_archive_description();
				woocommerce_product_archive_description();
				$description = ob_get_clean();
			}

			if ( has_excerpt( $post_id ) ) {
				$description = blocksy_entry_excerpt(
					array(
						'length'  => 40,
						'class'   => $description_class,
						'post_id' => $post_id,
					)
				);
			}
		} else {
			if ( ! is_search() ) {
				if (
					! is_author()
					&&
					! empty( get_the_archive_description() )
				) {
					$description = '<div class="' . $description_class . '">' . get_the_archive_description() . '</div>';
				}

				if ( is_author() ) {
					if ( ! empty( trim( blocksy_get_the_author_meta( 'description', blocksy_get_author_id() ) ) ) ) {
						$description = '<div class="' . $description_class . '">' . wp_kses_post( blocksy_get_the_author_meta( 'description', blocksy_get_author_id() ) ) . '</div>';
					}
				}
			} else {
				$title = blocksy_safe_sprintf(
					// translators: 1: span opening 2: span closing 3: the number of results
					__(
						'%1$sSearch Results for%2$s %3$s',
						'blocksy'
					),
					'<span>',
					'</span>',
					get_search_query()
				);

				if ( ! have_posts() ) {
					$description = blocksy_safe_sprintf(
						// translators: %1$s and %2$s are the opening and closing of the html tags
						__( '%1$sSorry, but nothing matched your search terms. Please try again with some different keywords.%2$s', 'blocksy' ),
						'<div class="' . $description_class . '">',
						'</div>'
					);
				}
			}
		}

		if ( is_home() && is_front_page() ) {
			if ( ! empty(
				blocksy_akg(
					'description',
					$single_hero_element,
					''
				)
			) ) {
				$description = '<div class="' . $description_class . '">' . blocksy_sanitize_html_for_display(
					array(
						'html' => blocksy_translate_dynamic(
							blocksy_akg(
								'description',
								$single_hero_element,
								(
								function_exists( 'is_shop' ) && is_shop()
								) ? __( 'This is where you can add new products to your store.', 'blocksy' ) : ''
							),
							$prefix . '_hero_custom_description'
						),
					)
				) . '</div>';
			}
		}

		/**
		 * Fires before the hero description is printed.
		 *
		 * @since 1.8.21
		 */
		do_action( 'blocksy:hero:description:before' );
		echo $description;
		/**
		 * Fires after the hero description is printed.
		 *
		 * @since 1.8.21
		 */
		do_action( 'blocksy:hero:description:after' );
	}

	if ( 'author_social_channels' === $single_hero_element['id'] ) {
		if ( is_author() ) {
			blocksy_author_social_channels(
				array(
					'new_tab'  => blocksy_akg(
						'link_target',
						$single_hero_element,
						'no'
					) === 'yes',

					'nofollow' => blocksy_akg(
						'link_nofollow',
						$single_hero_element,
						'no'
					) === 'yes',
				)
			);
		}
	}

	if ( 'custom_meta' === $single_hero_element['id'] ) {
		$author_page_meta_elements = blocksy_akg(
			'page_meta_elements',
			$single_hero_element,
			array(
				'joined'         => true,
				'articles_count' => true,
				'comments'       => true,
			)
		);

		$meta_type = blocksy_akg(
			'meta_type',
			$single_hero_element,
			'simple'
		);

		$meta_divider = blocksy_akg(
			'meta_divider',
			$single_hero_element,
			'slash'
		);

		$force_icons = false;

		$attr = array();

		if (
			null !== $meta_indexes['first']
			&&
			null !== $meta_indexes['second']
		) {
			if ( $index === $meta_indexes['first'] ) {
				/**
				 * Fires before the first hero meta element group is rendered.
				 *
				 * The dynamic portion of the hook name, `$single_hero_element['id']`,
				 * refers to the hero element id.
				 *
				 * @since 1.8.62
				 */
				do_action( 'blocksy:hero:' . $single_hero_element['id'] . ':first:before' );
			}

			if ( $index === $meta_indexes['second'] ) {
				/**
				 * Fires before the second hero meta element group is rendered.
				 *
				 * The dynamic portion of the hook name, `$single_hero_element['id']`,
				 * refers to the hero element id.
				 *
				 * @since 1.8.62
				 */
				do_action( 'blocksy:hero:' . $single_hero_element['id'] . ':second:before' );
			}
		}

		if (
			null !== $meta_indexes['first']
			&&
			null !== $meta_indexes['second']
		) {
			if ( $index === $meta_indexes['first'] ) {
				// $attr['data-id'] = 'first';
			}

			if ( $index === $meta_indexes['second'] ) {
				$attr['data-id'] = 'second';
			}
		}

		if ( is_author() ) {
			blocksy_author_meta_elements(
				array(
					'value' => $author_page_meta_elements,
					'attr'  => $attr,
				)
			);
		}

		$single_meta_elements = null;

		if ( is_singular() || $is_page ) {
			$single_meta_elements = blocksy_akg(
				'meta_elements',
				$single_hero_element,
				blocksy_post_meta_defaults(
					array(
						array(
							'id'                => 'author',
							'has_author_avatar' => 'yes',
							'enabled'           => true,
						),

						array(
							'id'      => 'post_date',
							'enabled' => true,
						),

						array(
							'id'      => 'comments',
							'enabled' => true,
						),

						array(
							'id'      => 'categories',
							'enabled' => true,
						),
					)
				)
			);

			$has_term_accent_color = 'yes';

			foreach ( $single_meta_elements as $single_meta_element ) {
				if ( 'categories' === $single_meta_element['id'] ) {
					$has_term_accent_color = blocksy_akg(
						'has_term_accent_color',
						$single_meta_element,
						'yes'
					);
				}
			}

			/**
			 * Filters the HTML attributes of the hero meta container.
			 *
			 * @since 1.9.7
			 *
			 * @param array $attr The hero meta container HTML attributes.
			 */
			$attr = apply_filters(
				'blocksy:hero:meta:container-attr',
				$attr
			);

			$meta_input = array(
				'attr'         => $attr,
				'meta_type'    => $meta_type,
				'meta_divider' => $meta_divider,
				'force_icons'  => $force_icons,
				'prefix'       => $prefix . '_hero_meta',
			);

			if ( 'no' === $has_term_accent_color ) {
				$meta_input['has_term_class'] = false;
			}

			/**
			 * Note to code reviewers: This line doesn't need to be escaped.
			 * Function blocksy_post_meta() used here escapes the value properly.
			 * Mainly because the function outputs SVG.
			 */
			echo blocksy_post_meta( $single_meta_elements, $meta_input );
		}

		if (
			null !== $meta_indexes['first']
			&&
			null !== $meta_indexes['second']
		) {
			if ( $index === $meta_indexes['first'] ) {
				/**
				 * Fires after the first hero meta element group is rendered.
				 *
				 * The dynamic portion of the hook name, `$single_hero_element['id']`,
				 * refers to the hero element id.
				 *
				 * @since 1.8.62
				 */
				do_action( 'blocksy:hero:' . $single_hero_element['id'] . ':first:after' );
			}

			if ( $index === $meta_indexes['second'] ) {
				/**
				 * Fires after the second hero meta element group is rendered.
				 *
				 * The dynamic portion of the hook name, `$single_hero_element['id']`,
				 * refers to the hero element id.
				 *
				 * @since 1.8.62
				 */
				do_action( 'blocksy:hero:' . $single_hero_element['id'] . ':second:after' );
			}
		}
	}

	/**
	 * Fires after a single hero element is rendered.
	 *
	 * The dynamic portion of the hook name, `$single_hero_element['id']`, refers
	 * to the hero element id.
	 *
	 * @since 1.7.10
	 */
	do_action( 'blocksy:hero:' . $single_hero_element['id'] . ':after' );
}
